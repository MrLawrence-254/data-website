# Lawrence Wanjuki | Portfolio

Personal portfolio for Lawrence Wanjuki, AI engineer and data analyst based in Nairobi, Kenya. Built for recruiters and hiring managers: what I do, proof of the work, and how to reach me, in one page.

## Tech

Plain HTML, CSS and a few lines of JavaScript. No build step, no framework, no dependencies beyond one Google Font.

## Run locally

```bash
git clone https://github.com/MrLawrence/portfolio.git
cd portfolio
python -m http.server 8000
```

Open <http://localhost:8000>.

## Deploy to GitHub Pages

1. Push the repository to GitHub.
2. Go to **Settings > Pages**.
3. Set the source to the `main` branch, root folder.
4. Your site goes live at `https://mrlawrence.github.io/portfolio/`.

## Project structure

```
.
├── index.html    # page content and metadata
├── styles.css    # design tokens and layout
├── script.js     # footer year
├── .gitignore
├── LICENSE
└── README.md
```

## Customising

- Colours and fonts are CSS variables at the top of `styles.css`.
- Add projects by copying an `<article class="project">` block in `index.html`.
- Add a screenshot of the finished site to this README once it is live.

## Design notes

- White and light-blue palette for a clean, credible look.
- Semantic HTML, keyboard focus styles, skip link and reduced-motion support.
- Responsive from phone to desktop.

## Licence

MIT. See [LICENSE](LICENSE).
